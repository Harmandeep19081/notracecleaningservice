function calculateQuote(){
  const base = Number(document.getElementById('service').value || 0);
  const rooms = Number(document.getElementById('rooms').value || 0);
  const baths = Number(document.getElementById('baths').value || 0);
  let extras = 0;
  document.querySelectorAll('.extra:checked').forEach(e => extras += Number(e.value));
  const total = base + (rooms * 25) + (baths * 35) + extras;
  document.getElementById('result').innerText = 'Estimated total: $' + total.toFixed(0) + ' + tax if applicable';
}
calculateQuote();
